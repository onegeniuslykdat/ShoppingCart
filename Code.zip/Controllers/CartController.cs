﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Migrations;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebApi2.Models;

namespace WebApi2.Controllers
{
    public class CartController : ApiController
    {
        ShopingCartEntities shopingCartEntities = new ShopingCartEntities();

        // See all products in your cart
        [Route("cart/api/customercart")]
        public IEnumerable<Product> Get(int custid)
        {
            List<Cart> customercart = shopingCartEntities.Carts.Where(ct => ct.CustomerID == custid).ToList();
            List<Product> customerprods = new List<Product>();
            foreach (Product prod in shopingCartEntities.Products)
            {
                if(customercart.Any(cc=>cc.ProductID==prod.ProductID))
                {
                    customerprods.Add(prod);
                }
            }
            return customerprods;
        }

        // Remove item from your cart
        [Route("cart/api/delete")]
        public HttpResponseMessage Delete(int prodid, int custid)
        {
            List<Cart> customercarts = shopingCartEntities.Carts.Where(ct=>ct.CustomerID==custid).ToList();
            Cart removalcart = customercarts.First(ct => ct.ProductID == prodid);

            Product product = shopingCartEntities.Products.First(p => p.ProductID == prodid);
            product.Quantity += removalcart.CustomerQuantity;
            shopingCartEntities.Products.AddOrUpdate(product);

            shopingCartEntities.Carts.Remove(removalcart);
            shopingCartEntities.SaveChanges();

            return Request.CreateResponse(HttpStatusCode.OK, "Item removed");
        }
    }
}
