﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Migrations;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using WebApi2.Models;

namespace WebApi2.Controllers
{
    public class CustomerController : ApiController
    {
        ShopingCartEntities shopingCartEntities = new ShopingCartEntities();

        // Gets a customer on sign in
        [Route("customer/api/signin")]
        public Customer Get(string e, string w)
        {
            Request.CreateResponse(HttpStatusCode.OK);
            return shopingCartEntities.Customers.First(c => c.CustomerEmail == e && c.pwd == c.HashPwd(w));
        }

        // Creates a customer on sign up
        [Route("customer/api/signup")]
        public HttpResponseMessage Post([FromUri]string n, string p, string e, string pw)
        {
            try
            {
                Customer cust = new Customer(n, p, e, pw);
                shopingCartEntities.Customers.Add(cust);
                shopingCartEntities.SaveChanges();

                return Request.CreateResponse(HttpStatusCode.OK, "Sign up successful");
            }
            catch (HttpException)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Something went wrong. please try again");
            }
        }

        // Updates a customer
        [Route("customer/api/update")]
        public HttpResponseMessage Put(int id, [FromBody]string n, string p, string e)
        {
            Customer ct = shopingCartEntities.Customers.First(c => c.CustomerID == id);

            ct.CustomerName = n; ct.CustomerPhone = p; ct.CustomerEmail = e;
            shopingCartEntities.Customers.AddOrUpdate(ct);
            shopingCartEntities.SaveChanges();

            return Request.CreateResponse(HttpStatusCode.OK, "Update Successful");
        }

        // Deletes a customer
        [Route("customer/api/delete")]
        public HttpResponseMessage Delete(int id)
        {
            try
            {
                Customer p = shopingCartEntities.Customers.First(c => c.CustomerID == id);

                shopingCartEntities.Customers.Remove(p);
                shopingCartEntities.SaveChanges();

                return Request.CreateResponse(HttpStatusCode.OK, "You have been removed");
            }
            catch (Exception)
            {
                return Request.CreateResponse(HttpStatusCode.OK, "Something went wrong. please try again");
            }
        }
    }
}
