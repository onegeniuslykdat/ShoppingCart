﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Migrations;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Security.Cryptography.Xml;
using System.Web;
using System.Web.Http;
//using System.Web.Mvc;
using WebApi2.Models;

namespace WebApi2.Controllers
{
    public class ProductController : ApiController
    {
        ShopingCartEntities shopingCartEntities = new ShopingCartEntities();

        // Gets all products to display, you may decide to not display out of stock products
        [Route("product/api/getall")]
        public IEnumerable<Product> GetAll()
        {
            IEnumerable<Product> allproducts = shopingCartEntities.Products;

            return allproducts;
        }

        [Route("product/api/get")]
        public Product Get(int id)
        {
            Product p = shopingCartEntities.Products.First(pr=>pr.ProductID==id);
            //if (p == null) { return new Product("null", 0, "null", "null"); }

            return shopingCartEntities.Products.First(pr => pr.ProductID == id);

        }

        // After seeing more details about a product, you can add it to your cart
        [Route("product/api/posttocart")]
        public HttpResponseMessage PosttoCart(int prodid, int custid, int custqn)
        {
            Cart cart = new Cart();
            cart.CustomerID = custid;
            cart.CustomerQuantity = custqn;
            cart.ProductID = prodid;

            Product pr = shopingCartEntities.Products.First(p => p.ProductID == prodid);
            if(pr.Quantity <= 0)
            {
                pr.Quantity = 0;
                pr.OutofStock = true.ToString();
            }
            else
            {
                pr.Quantity -= custqn;
            }
            shopingCartEntities.Carts.Add(cart);

            shopingCartEntities.Products.AddOrUpdate(pr);

            shopingCartEntities.SaveChanges();

            return Request.CreateResponse(HttpStatusCode.OK, "Product added to cart");
        }

        // Creates a product
        [Route("product/api/post")]
        public HttpResponseMessage Create([FromUri]/*Product prod*/int id, string n, int q, int pr, string u, string o)
        {
            try
            {
                Product p = new Product(n,q,pr,u,o);

                shopingCartEntities.Products.Add(p);
                shopingCartEntities.SaveChanges();

                return Request.CreateResponse(HttpStatusCode.OK, "Product created");
            }
            catch (HttpException)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Something went wrong. please try again");
            }
        }

        // Updates a product
        [Route("product/api/update")]
        public HttpResponseMessage Put(int id, [FromUri]string n, int q, int pr, string u, string o)
        {
            Product p = shopingCartEntities.Products.First(pd => pd.ProductID == id);

            p.ProductName = n;
            p.Quantity = q;
            p.Price = pr;
            p.PictureURL = u;
            p.OwnerEmail = o;

            shopingCartEntities.Products.AddOrUpdate(p);
            shopingCartEntities.SaveChanges();
            return Request.CreateResponse(HttpStatusCode.OK, "Details Updated");
        }

        // Removes product from database
        [Route("product/api/delete")]
        public HttpResponseMessage DeleteProduct(int id)
        {
            try
            {
                Product p = shopingCartEntities.Products.First(pr => pr.ProductID == id);
                List<Cart> remcarts = shopingCartEntities.Carts.Where(c => c.ProductID == p.ProductID).ToList();
                foreach (Cart ct in remcarts)
                {
                    if(shopingCartEntities.Carts.Contains(ct))
                    {
                        shopingCartEntities.Carts.Remove(ct);
                    }
                }
                shopingCartEntities.Products.Remove(p);
                
                shopingCartEntities.SaveChanges();
                return Request.CreateResponse(HttpStatusCode.OK, "Removal Successful");
            }
            catch (Exception E)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest, E.Message);
            }
        }
    }
}
